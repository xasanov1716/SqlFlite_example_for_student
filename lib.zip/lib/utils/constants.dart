const String adminEmail = "admin@gmail.com";

const defaultImageConstant = "Select Image";